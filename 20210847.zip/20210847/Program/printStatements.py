def find (record):
    record = print("Record found")

def wronginput (output):
    output = print ("Invalid input Try again..")
    return output

def add1 (subject):
    subject = print ("Subject Recorded")
    return subject

def add2 (book):
    book = print("Book Recorded")
    return book

def add3 (chapter):
    chapter = print ("Chapter Recorded")
    return chapter

def update1 (suject2):
    subject1 = print("Subject Updated")
    return subject1

def update2 (book2):
    book1 = print("Book Updated")
    return book1

def update3 (chapter2):
    chapter1 = print("Chapter Updated")
    return  chapter1

def delete1 (subject3):
    subject2 = print("Subject Deleted")
    return subject2

def delete2 (book3):
    book2 = print("Book Deleted")
    return book2

def delete3 (chapter3):
    chapter2 = print("Chapter Deleted")
    return chapter2

def main (run):
    run = print("Process Finished")
    return run
